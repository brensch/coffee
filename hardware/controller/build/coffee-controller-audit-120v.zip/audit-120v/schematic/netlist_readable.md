# Readable netlist (120 V build)

Each net, then the part pins on it. Part values are in the table at the end.

## Mains side (hazardous voltage)

- **AC_L**: F1.1, J1.1, Q2.2, Q3.2, R2.1, R3.1, R4.1, R6.1
- **AC_L_FUSED**: F1.2, PS1.1, RV1.1
- **AC_N**: J1.2, PS1.2, RV1.2
- **HEATER_GATE**: Q1.3, U1.4
- **HEATER_OPTO**: R1.2, U1.6
- **HTR_A**: J2.1, Q1.1
- **HTR_B**: J2.2, Q1.2, R1.1
- **PUMP_GATE**: Q2.3, U2.4
- **PUMP_L**: C1.2, J3.2, Q2.1
- **PUMP_OPTO**: R2.2, U2.6
- **PUMP_SNUB**: C1.1, R3.2
- **VALVE_GATE**: Q3.3, R5.1, U3.4
- **VALVE_L**: C2.2, J3.1, Q3.1, R5.2
- **VALVE_OPTO**: R4.2, U3.6
- **VALVE_SNUB**: C2.1, R6.2

## SELV side (low voltage)

- **+3V3**: C3.1, C4.1, C7.1, R10.1, R11.1, R15.1, U4.3, U5.2
- **+5V**: C6.1, D2.1, J6.1, PS1.4, U5.3
- **CC1**: J4.A5, R13.1
- **CC2**: J4.B5, R14.1
- **EN**: C5.1, R10.2, U4.8
- **GND**: C3.2, C4.2, C5.2, C6.2, C7.2, C8.2, C9.2, D1.1, J4.A1, J4.A12, J4.B1, J4.B12, J4.S1, J5.2, J6.3, J7.3, PS1.3, R13.2, R14.2, R17.2, TP2.1, U1.2, U2.2, U3.2, U4.1, U4.11, U4.14, U4.2, U4.36, U4.37, U4.38, U4.39, U4.40, U4.41, U4.42, U4.43, U4.44, U4.45, U4.46, U4.47, U4.48, U4.49, U4.50, U4.51, U4.52, U4.53, U5.1
- **HEATER_CMD**: R7.1, U4.26
- **HEATER_OPTO_A**: R7.2, U1.1
- **IO8_STRAP**: R11.2, U4.22
- **IO9_BOOT**: TP1.1, U4.23
- **NTC**: C8.1, J5.1, R15.2, U4.13
- **PUMP_CMD**: R8.1, U4.25
- **PUMP_OPTO_A**: R8.2, U2.1
- **P_ADC**: C9.1, R16.2, R17.1, U4.12
- **P_SIG**: J6.2, R16.1
- **STATUS**: R12.1, U4.29
- **STATUS_A**: D1.2, R12.2
- **SW_BREW**: J7.1, U4.15
- **SW_STEAM**: J7.2, U4.16
- **USB_D+**: J4.A6, J4.B6, U4.18
- **USB_D-**: J4.A7, J4.B7, U4.17
- **VALVE_CMD**: R9.1, U4.24
- **VALVE_OPTO_A**: R9.2, U3.1
- **VBUS**: D2.2, J4.A4, J4.A9, J4.B4, J4.B9

## Parts

| Ref | Value / part | Footprint |
|---|---|---|
| C1 | 10nF X2 (Murata GA355QR7GB103KW01L (10 nF X2 250 VAC, 2220)) | C_2220_5750Metric |
| C2 | 10nF X2 (Murata GA355QR7GB103KW01L (10 nF X2 250 VAC, 2220)) | C_2220_5750Metric |
| C3 | 10uF (C) | C_1206_3216Metric |
| C4 | 100nF (C) | C_0603_1608Metric |
| C5 | 1uF (C) | C_0603_1608Metric |
| C6 | 22uF 10V (C) | C_1206_3216Metric |
| C7 | 22uF 6.3V (C) | C_1206_3216Metric |
| C8 | 100nF (C) | C_0603_1608Metric |
| C9 | 100nF (C) | C_0603_1608Metric |
| D1 | green (LED) | LED_0603_1608Metric |
| D2 | SS14 (SS14) | D_SMA |
| F1 | T500mA (Littelfuse 37205000411 (TR5, 500 mA slow, 250 VAC)) | Fuse_Littelfuse_372_D8.50mm |
| H1 | M3 (MountingHole) | MountingHole_3.2mm_M3 |
| H2 | M3 (MountingHole) | MountingHole_3.2mm_M3 |
| H3 | M3 (MountingHole) | MountingHole_3.2mm_M3 |
| J1 | Mains in (Screw_Terminal_01x02_5.08) | TerminalBlock_Phoenix_MKDS-1,5-2-5.08_1x02_P5.08mm_Horizontal |
| J2 | Heater (Screw_Terminal_01x02_5.08) | TerminalBlock_Phoenix_MKDS-1,5-2-5.08_1x02_P5.08mm_Horizontal |
| J3 | Valve / pump (Screw_Terminal_01x02_5.08) | TerminalBlock_Phoenix_MKDS-1,5-2-5.08_1x02_P5.08mm_Horizontal |
| J4 | USB-C (GCT USB4105-GF-A) | USB_C_Receptacle_GCT_USB4105-xx-A_16P_TopMnt_Horizontal |
| J5 | Thermistor (JST_PH_2) | JST_PH_B2B-PH-K_1x02_P2.00mm_Vertical |
| J6 | Pressure (JST_PH_3) | JST_PH_B3B-PH-K_1x03_P2.00mm_Vertical |
| J7 | Switches (JST_PH_3) | JST_PH_B3B-PH-K_1x03_P2.00mm_Vertical |
| PS1 | HLK-PM05 (Hi-Link HLK-PM05) | Converter_ACDC_Hi-Link_HLK-PMxx |
| Q1 | BTA24-800BW (ST BTA24-800BWRG (25 A, 800 V, insulated tab, snubberless)) | TO-220-3_Vertical |
| Q2 | BTA08-800CW (ST BTA08-800CWRG (8 A, 800 V, insulated tab, snubberless)) | TO-220-3_Vertical |
| Q3 | Z0109NN (ST Z0109NN5AA4 (1 A, 800 V, IGT 10 mA)) | SOT-223-3_TabPin2 |
| R1 | 360 (R) | R_1206_3216Metric |
| R2 | 360 (R) | R_1206_3216Metric |
| R3 | 100 1W (R) | R_2512_6332Metric |
| R4 | 360 (R) | R_1206_3216Metric |
| R5 | 330 (R) | R_1206_3216Metric |
| R6 | 100 1W (R) | R_2512_6332Metric |
| R7 | 150 (R) | R_0603_1608Metric |
| R8 | 150 (R) | R_0603_1608Metric |
| R9 | 150 (R) | R_0603_1608Metric |
| R10 | 10k (R) | R_0603_1608Metric |
| R11 | 10k (R) | R_0603_1608Metric |
| R12 | 1k (R) | R_0603_1608Metric |
| R13 | 5.1k (R) | R_0603_1608Metric |
| R14 | 5.1k (R) | R_0603_1608Metric |
| R15 | 8.2k 0.1% (R) | R_0603_1608Metric |
| R16 | 10k 0.1% (R) | R_0603_1608Metric |
| R17 | 20k 0.1% (R) | R_0603_1608Metric |
| RV1 | 10D271K (Bourns MOV-10D271K (120 V) / 10D561K (230 V)) | RV_Disc_D7mm_W4.2mm_P5mm |
| TP1 | BOOT (TestPad) | TestPoint_Pad_D1.5mm |
| TP2 | GND (TestPad) | TestPoint_Pad_D1.5mm |
| U1 | MOC3083 (onsemi MOC3083TVM (0.4" leads)) | DIP-6_W10.16mm |
| U2 | MOC3083 (onsemi MOC3083TVM (0.4" leads)) | DIP-6_W10.16mm |
| U3 | MOC3083 (onsemi MOC3083TVM (0.4" leads)) | DIP-6_W10.16mm |
| U4 | ESP32-C6-MINI-1U-H4 (ESP32-C6-MINI-1U-H4) | ESP32-C6-MINI-1U |
| U5 | AMS1117-3.3 (AMS1117-3.3) | SOT-223-3_TabPin2 |
